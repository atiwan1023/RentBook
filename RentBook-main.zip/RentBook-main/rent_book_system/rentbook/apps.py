from django.apps import AppConfig


class RentbookConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rentbook'
