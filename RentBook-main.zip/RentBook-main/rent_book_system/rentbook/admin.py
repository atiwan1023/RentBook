from django.contrib import admin
from rentbook.models import Rentbook
# Register your models here.
admin.site.register(Rentbook)